package core.cg.ois.service;

import java.util.List;

import core.cg.ois.beans.AccountMaster;
import core.cg.ois.beans.Customer;
import core.cg.ois.beans.ServiceTracker;
import core.cg.ois.beans.Transaction;
import core.cg.ois.dao.BankDao;
import core.cg.ois.dao.BankDaoImpl;
import core.cg.ois.exception.LoginException;

public class BankServiceImpl implements IBankservice{
	
	BankDao dao = new BankDaoImpl();

	@Override
	public void insertAccountHolder(Customer customer) throws LoginException {
		dao.insertAccountHolder(customer);
		
	}

	@Override
	public void insertAccount(AccountMaster account) throws LoginException {
		dao.insertAccount(account);
		
	}

	@Override
	public int createAccountNo() throws LoginException {
		// TODO Auto-generated method stub
		return dao.createAccountNo();
	}

	@Override
	public void updateTracker(int accountId, int serviceId, String status) throws LoginException {
		dao.updateTracker(accountId, serviceId, status);
		
	}

	@Override
	public List<ServiceTracker> showall() throws LoginException {
		// TODO Auto-generated method stub
		return dao.showall();
	}

	@Override
	public ServiceTracker searchserviceid(int serviceId) throws LoginException {
		// TODO Auto-generated method stub
		return dao.searchserviceid(serviceId);
	}

	@Override
	public List<Transaction> getAllTransactions() throws LoginException {
		// TODO Auto-generated method stub
		return dao.getAllTransactions();
	}
	
	

}
