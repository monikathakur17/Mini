package core.cg.ois.beans;

public class Customer 
{
	private int accountId;
	private String customerName;
	private String email;
	private String address;
	private String panCard;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int accountId, String customerName, String email,
			String address, String panCard) {
		super();
		this.accountId = accountId;
		this.customerName = customerName;
		this.email = email;
		this.address = address;
		this.panCard = panCard;
	}
	public Customer(String customer_Name, String email2, String address2,
			int accountId) {
		// TODO Auto-generated constructor stub
	}
	public Customer(String customer_Name, String email2, String address2,
			String pancard2) {
		this.customerName = customer_Name;
		this.email = email2;
		this.address = address2;
		this.panCard = pancard2;
	}
	@Override
	public String toString() {
		return "Customer [accountId=" + accountId + ", customerName="
				+ customerName + ", email=" + email + ", address=" + address
				+ ", panCard=" + panCard + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((panCard == null) ? 0 : panCard.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (accountId != other.accountId)
			return false;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (panCard == null) {
			if (other.panCard != null)
				return false;
		} else if (!panCard.equals(other.panCard))
			return false;
		return true;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPanCard() {
		return panCard;
	}
	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}
	
	
}
